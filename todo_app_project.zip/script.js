// Function to add a new task
function addTask() {
    const taskInput = document.getElementById('todo-input');
    const taskText = taskInput.value.trim();

    // If input is not empty, add the task
    if (taskText !== "") {
        const taskList = document.getElementById('todo-list');

        // Create a new list item
        const listItem = document.createElement('li');
        listItem.classList.add('task');

        // Add task text to the list item
        listItem.innerHTML = `
            <span onclick="toggleTask(this)">${taskText}</span>
            <button class="edit-btn" onclick="editTask(this)">Edit</button>
            <button class="remove-btn" onclick="removeTask(this)">Remove</button>
        `;

        // Append the new list item to the task list
        taskList.appendChild(listItem);

        // Clear the input field
        taskInput.value = '';
    }
}

// Function to remove a task
function removeTask(button) {
    const listItem = button.parentElement;
    listItem.remove();
}

// Function to toggle a task as completed
function toggleTask(span) {
    span.classList.toggle('completed');
}

// Function to edit a task
function editTask(button) {
    const listItem = button.parentElement;
    const taskText = listItem.querySelector('span');

    // Allow the user to edit the task text
    const newTaskText = prompt("Edit your task:", taskText.textContent);

    if (newTaskText !== null && newTaskText.trim() !== "") {
        taskText.textContent = newTaskText.trim();
    }
}
